![](https://raw.githubusercontent.com/Matthewpco/WP-Plugin-Product-Variation-Images/main/product-variation-images.png)

# WordPress plugin to add additional product variation images

<br>

## 🙋‍♂️ Introduction

- This plugin creates a new  field in product variations to add additional images. The additional images are then appended to a selected space in the products template, when said variation is selected.

<br>

## 📜 Features

- jQuery
- PHP
- WordPress Plugin


  <br>

